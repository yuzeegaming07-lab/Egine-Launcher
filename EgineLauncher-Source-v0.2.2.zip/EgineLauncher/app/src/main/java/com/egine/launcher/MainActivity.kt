package com.egine.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0B1015)
private val Sidebar = Color(0xFF111920)
private val Card = Color(0xFF17232B)
private val Card2 = Color(0xFF1D2B34)
private val Accent = Color(0xFF76E2A4)
private val TextMain = Color(0xFFF2F6F4)
private val TextMuted = Color(0xFF91A39C)

private enum class Page(val title: String, val icon: ImageVector) {
    Home("Overview", Icons.Default.Dashboard),
    Instances("Instances", Icons.Default.ViewList),
    Mods("Mods", Icons.Default.Extension),
    Packs("Resource Packs", Icons.Default.Collections),
    Accounts("Accounts", Icons.Default.AccountCircle),
    Settings("Settings", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EgineDesktopApp() }
    }
}

@Composable
private fun EgineDesktopApp() {
    var page by remember { mutableStateOf(Page.Home) }
    var selectedVersion by remember { mutableStateOf("1.21.4") }
    var ram by remember { mutableFloatStateOf(3f) }
    var compact by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent, background = Bg, surface = Card,
        onPrimary = Bg, onBackground = TextMain, onSurface = TextMain
    )) {
        BoxWithConstraints(Modifier.fillMaxSize().background(Bg)) {
            val desktop = maxWidth >= 700.dp
            if (desktop) {
                Row(Modifier.fillMaxSize()) {
                    SidebarNav(page, { page = it }, compact)
                    Column(Modifier.weight(1f).fillMaxHeight()) {
                        TopBar(page, selectedVersion)
                        PageContent(page, selectedVersion, { selectedVersion = it }, ram, { ram = it })
                    }
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    TopBar(page, selectedVersion)
                    PageContent(page, selectedVersion, { selectedVersion = it }, ram, { ram = it }, Modifier.weight(1f))
                    NavigationBar(containerColor = Sidebar, contentColor = TextMuted) {
                        listOf(Page.Home, Page.Instances, Page.Mods, Page.Settings).forEach { item ->
                            NavigationBarItem(
                                selected = page == item, onClick = { page = item },
                                icon = { Icon(item.icon, contentDescription = item.title) },
                                label = { Text(item.title, maxLines = 1, fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Accent, selectedTextColor = Accent,
                                    indicatorColor = Color(0xFF294638),
                                    unselectedIconColor = TextMuted, unselectedTextColor = TextMuted
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SidebarNav(current: Page, onSelect: (Page) -> Unit, compact: Boolean) {
    var collapsed by remember { mutableStateOf(false) }
    val narrow = collapsed
    Column(
        Modifier.width(if (narrow) 76.dp else 228.dp).fillMaxHeight()
            .background(Sidebar).padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Color(0xFF244B39), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                Text("E", color = Accent, fontWeight = FontWeight.Black, fontSize = 24.sp)
            }
            if (!narrow) {
                Spacer(Modifier.width(11.dp))
                Column {
                    Text("EGINE", color = Accent, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                    Text("JAVA LAUNCHER", color = TextMuted, fontSize = 9.sp, letterSpacing = 1.sp)
                }
            }
        }
        Spacer(Modifier.height(30.dp))
        Text(if (narrow) " " else "WORKSPACE", color = TextMuted, fontSize = 10.sp, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(10.dp))
        Page.values().forEach { item ->
            val selected = current == item
            Row(
                Modifier.fillMaxWidth().padding(vertical = 3.dp)
                    .background(if (selected) Color(0xFF234333) else Color.Transparent, RoundedCornerShape(12.dp))
                    .clickable { onSelect(item) }.padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(item.icon, contentDescription = item.title, tint = if (selected) Accent else TextMuted)
                if (!narrow) {
                    Spacer(Modifier.width(13.dp))
                    Text(item.title, color = if (selected) Accent else TextMain, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal, fontSize = 13.sp)
                }
            }
        }
        Spacer(Modifier.weight(1f))
        if (!narrow) {
            Surface(color = Card, shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text("BUILD", color = TextMuted, fontSize = 9.sp, letterSpacing = 1.sp)
                    Text("Egine 0.2.0", color = TextMain, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("Egine Launcher", color = Accent, fontSize = 10.sp)
                }
            }
        }
        TextButton(onClick = { collapsed = !collapsed }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
            Icon(if (narrow) Icons.Default.ChevronRight else Icons.Default.ChevronLeft, contentDescription = "Toggle sidebar", tint = TextMuted)
            if (!narrow) Text("Collapse", color = TextMuted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun TopBar(page: Page, version: String) {
    Row(
        Modifier.fillMaxWidth().background(Bg).padding(horizontal = 24.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(page.title, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 23.sp)
            Text("Manage your Minecraft Java setup", color = TextMuted, fontSize = 11.sp)
        }
        Surface(color = Card, shape = RoundedCornerShape(10.dp)) {
            Row(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Circle, contentDescription = null, tint = Accent, modifier = Modifier.size(8.dp))
                Spacer(Modifier.width(8.dp))
                Text("Profile  •  $version", color = TextMain, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun PageContent(
    page: Page, version: String, onVersion: (String) -> Unit,
    ram: Float, onRam: (Float) -> Unit, modifier: Modifier = Modifier
) {
    Column(modifier.fillMaxSize().padding(horizontal = 24.dp).padding(bottom = 20.dp)) {
        when (page) {
            Page.Home -> Overview(version, onVersion)
            Page.Instances -> Instances(version, onVersion)
            Page.Mods -> SimpleLibrary("Mods", "Manage Fabric, Forge and other compatible mod files.", "No mods imported yet")
            Page.Packs -> SimpleLibrary("Resource Packs", "Keep your textures and visual packs organized.", "No resource packs imported yet")
            Page.Accounts -> Accounts()
            Page.Settings -> Settings(ram, onRam)
        }
    }
}

@Composable
private fun Overview(version: String, onManage: () -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Surface(color = Color(0xFF1B3A2C), shape = RoundedCornerShape(22.dp)) {
                Row(Modifier.fillMaxWidth().padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("READY WHEN YOU ARE", color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Spacer(Modifier.height(12.dp))
                        Text("Your Minecraft.", color = TextMain, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Your setup. Your rules.", color = Color(0xFFC1D9CC), fontSize = 14.sp)
                        Spacer(Modifier.height(20.dp))
                        Button(onClick = onManage, colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg)) {
                            Text("Manage instance")
                            Spacer(Modifier.width(6.dp))
                            Icon(Icons.Default.ArrowForward, contentDescription = null)
                        }
                    }
                    Box(Modifier.size(112.dp).background(Color(0xFF28523D), RoundedCornerShape(24.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.SportsEsports, contentDescription = null, tint = Accent, modifier = Modifier.size(62.dp))
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("ACTIVE INSTANCE", version, "Selected profile", Modifier.weight(1f))
                StatCard("LOADER", "Vanilla", "No mod loader", Modifier.weight(1f))
                StatCard("RUNTIME", "Not linked", "Setup required", Modifier.weight(1f))
            }
        }
        item { SectionTitle("QUICK ACCESS") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ActionTile("Instances", "Versions & profiles", Icons.Default.ViewList, Modifier.weight(1f))
                ActionTile("Mods", "Customize gameplay", Icons.Default.Extension, Modifier.weight(1f))
                ActionTile("Resource Packs", "Change visuals", Icons.Default.Collections, Modifier.weight(1f))
            }
        }
        item {
            Surface(color = Card, shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = Accent)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Prototype notice", color = TextMain, fontWeight = FontWeight.Bold)
                        Text("This build is a launcher UI prototype. Minecraft runtime, account sign-in and game installation are not connected yet.", color = TextMuted, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, detail: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = Card, shape = RoundedCornerShape(15.dp)) {
        Column(Modifier.padding(15.dp)) {
            Text(label, color = TextMuted, fontSize = 9.sp, letterSpacing = 1.sp)
            Spacer(Modifier.height(8.dp))
            Text(value, color = TextMain, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text(detail, color = TextMuted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(title, color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
}

@Composable
private fun ActionTile(title: String, subtitle: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Surface(modifier, color = Card, shape = RoundedCornerShape(15.dp)) {
        Column(Modifier.padding(14.dp)) {
            Icon(icon, tint = Accent, contentDescription = null)
            Spacer(Modifier.height(10.dp))
            Text(title, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(subtitle, color = TextMuted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun Instances(selected: String, onSelect: (String) -> Unit) {
    val versions = listOf("1.21.4", "1.21.3", "1.20.4", "1.20.1", "1.19.4", "1.18.2", "1.16.5", "1.12.2")
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Game profiles", color = TextMuted, fontSize = 12.sp)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(versions) { v ->
                Surface(color = if (v == selected) Color(0xFF203D30) else Card, shape = RoundedCornerShape(13.dp),
                    modifier = Modifier.fillMaxWidth().clickable { onSelect(v) }) {
                    Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Cube, contentDescription = null, tint = Accent)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Minecraft $v", color = TextMain, fontWeight = FontWeight.Bold)
                            Text(if (v == selected) "Selected profile" else "Vanilla profile • sample", color = TextMuted, fontSize = 10.sp)
                        }
                        if (v == selected) Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Accent)
                    }
                }
            }
        }
    }
}

@Composable
private fun SimpleLibrary(title: String, subtitle: String, empty: String) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(subtitle, color = TextMuted, fontSize = 12.sp)
        Surface(color = Card, shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.FolderOpen, contentDescription = null, tint = TextMuted, modifier = Modifier.size(42.dp))
                Spacer(Modifier.height(10.dp))
                Text(empty, color = TextMain, fontWeight = FontWeight.Bold)
                Text("File manager integration will be added in a later build.", color = TextMuted, fontSize = 11.sp)
                Spacer(Modifier.height(12.dp))
                OutlinedButton(onClick = {}, enabled = false) { Icon(Icons.Default.Add, null); Text("Import $title") }
            }
        }
    }
}

@Composable
private fun Accounts() {
    var provider by remember { mutableStateOf("Offline") }
    var offlineName by remember { mutableStateOf("Player") }
    var elyUsername by remember { mutableStateOf("") }
    var elyPassword by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("Choose an account type to continue.") }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Choose how Egine identifies your player profile.", color = TextMuted, fontSize = 12.sp)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Offline", "Microsoft", "Ely.by").forEach { option ->
                val selected = provider == option
                Surface(
                    color = if (selected) Color(0xFF234333) else Card,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f).clickable {
                        provider = option
                        message = when (option) {
                            "Offline" -> "Offline profiles work only where offline authentication is permitted."
                            "Microsoft" -> "Microsoft sign-in is optional and will use the official secure sign-in flow when implemented."
                            else -> "Ely.by is a third-party account provider. Use it only with servers that support Ely.by authentication."
                        }
                    }
                ) {
                    Column(Modifier.padding(vertical = 14.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            when (option) {
                                "Offline" -> Icons.Default.Person
                                "Microsoft" -> Icons.Default.Cloud
                                else -> Icons.Default.VerifiedUser
                            },
                            contentDescription = null,
                            tint = if (selected) Accent else TextMuted
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(option, color = if (selected) Accent else TextMain, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        Surface(color = Card, shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                when (provider) {
                    "Offline" -> {
                        Text("Offline profile", color = TextMain, fontWeight = FontWeight.Bold)
                        Text("No online account is required. Choose a local player name.", color = TextMuted, fontSize = 11.sp)
                        OutlinedTextField(
                            value = offlineName,
                            onValueChange = { offlineName = it.take(16).filter { ch -> ch.isLetterOrDigit() || ch == '_' } },
                            label = { Text("Player name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(
                            onClick = { message = if (offlineName.length in 3..16) "Offline profile '${offlineName}' selected (local UI only)." else "Use a name with 3–16 letters, numbers or underscores." },
                            enabled = offlineName.length in 3..16,
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg)
                        ) { Text("Use offline profile") }
                    }
                    "Microsoft" -> {
                        Text("Microsoft account", color = TextMain, fontWeight = FontWeight.Bold)
                        Text("Optional. The finished launcher should use Microsoft's official OAuth/device-code flow; Egine will never ask for your Microsoft password directly.", color = TextMuted, fontSize = 11.sp)
                        Button(onClick = { message = "Microsoft authentication is not connected in this prototype." }, enabled = false) {
                            Text("Connect Microsoft — coming later")
                        }
                    }
                    "Ely.by" -> {
                        Text("Ely.by account", color = TextMain, fontWeight = FontWeight.Bold)
                        Text("Third-party authentication. Enter credentials only after secure Ely.by authentication is implemented. Do not reuse your Microsoft password.", color = TextMuted, fontSize = 11.sp)
                        OutlinedTextField(
                            value = elyUsername, onValueChange = { elyUsername = it },
                            label = { Text("Ely.by username or email") },
                            singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = elyPassword, onValueChange = { elyPassword = it },
                            label = { Text("Password (demo field only)") },
                            singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                        Button(onClick = { message = "Ely.by sign-in is not connected. No credentials were sent or saved." }, enabled = false) {
                            Text("Connect Ely.by — coming later")
                        }
                    }
                }
                Divider(color = Color(0xFF30404A))
                Text(message, color = Accent, fontSize = 11.sp)
            }
        }

        Text(
            "Compatibility note: Offline mode is not a way to access premium-only servers. It works only in single-player or on servers that explicitly allow offline-mode identities. Ely.by works only with servers configured to accept Ely.by authentication.",
            color = TextMuted, fontSize = 10.sp
        )
    }
}

@Composable
private fun Settings(ram: Float, onRam: (Float) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Surface(color = Card, shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("Memory allocation", color = TextMain, fontWeight = FontWeight.Bold)
                Text("${ram.toInt()} GB", color = Accent, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                Slider(value = ram, onValueChange = onRam, valueRange = 1f..8f, steps = 6)
                Text("UI preference only; it is not yet passed to a game runtime.", color = TextMuted, fontSize = 10.sp)
            }
        }
        Surface(color = Card, shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("Appearance", color = TextMain, fontWeight = FontWeight.Bold)
                Text("Egine Dark • desktop layout adapts to screen width", color = TextMuted, fontSize = 11.sp)
            }
        }
        Surface(color = Card, shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("About Egine Launcher", color = TextMain, fontWeight = FontWeight.Bold)
                Text("Version 0.2.1 • Android 8.0+", color = TextMuted, fontSize = 11.sp)
            }
        }
    }
}
