# Egine Launcher 0.2.2

Android Studio starter project for an original Minecraft: Java Edition launcher interface.

## UI updates
- Desktop-inspired sidebar navigation on wide screens / landscape / tablets.
- Sidebar can collapse and expand.
- Navigation switches between Overview, Instances, Mods, Resource Packs, Accounts and Settings.
- Compact bottom navigation on narrow portrait screens.
- Dark desktop theme and adaptive layout.

## Current functionality
- Select a sample version profile.
- Account provider UI: Offline, optional Microsoft, and Ely.by.
- Adjust a UI-only RAM preference.
- Navigate between all launcher screens.

## Not implemented yet
This is a buildable UI prototype, **not a functional Minecraft runtime**. It does not download game assets/libraries, authenticate Microsoft or Ely.by accounts, install mod loaders, import mod files, or launch Minecraft. The account screen is UI-only; credentials are not transmitted or saved. Those require a compatible Android Java/LWJGL runtime and a complete version-manifest/install/launch pipeline.

Runtime integration candidate: Amethyst-Android:
https://github.com/AngelAuraMC/Amethyst-Android
Review its current source, build requirements, and license before integrating or redistributing it. Runtime components retain their own licenses and notices.

## Build APK
1. Install Android Studio and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Use JDK 17 for Gradle.
4. Wait for Gradle sync.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

Package: `com.egine.launcher`
Minimum Android: 8.0 (API 26)
Target SDK: 35
Version: 0.2.2

## License
Starter code is MIT. Any future runtime components retain their own licenses.
